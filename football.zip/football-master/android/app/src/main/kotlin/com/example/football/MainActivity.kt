package com.example.football

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
